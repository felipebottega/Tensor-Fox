# __init__.py
__version__ = '1.0.14'
def version():
    return (1, 0, 14)

from .TensorFox import *

