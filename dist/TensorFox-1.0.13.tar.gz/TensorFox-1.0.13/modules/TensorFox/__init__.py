# __init__.py
__version__ = '1.0.13'
def version():
    return (1, 0, 13)

from .TensorFox import *

