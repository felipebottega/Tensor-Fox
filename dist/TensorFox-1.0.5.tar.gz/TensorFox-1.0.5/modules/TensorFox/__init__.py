# __init__.py
__version__ = '1.0.5'
def version():
    return (1, 0, 5)

from .TensorFox import *
