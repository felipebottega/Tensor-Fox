# __init__.py
__version__ = '1.0.4'
def version():
    return (1, 0, 4)

from .TensorFox import *
