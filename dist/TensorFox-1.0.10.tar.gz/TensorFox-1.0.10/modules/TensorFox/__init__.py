# __init__.py
__version__ = '1.0.10'
def version():
    return (1, 0, 10)

from .TensorFox import *
