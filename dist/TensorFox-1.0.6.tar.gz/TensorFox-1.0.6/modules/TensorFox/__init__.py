# __init__.py
__version__ = '1.0.6'
def version():
    return (1, 0, 6)

from .TensorFox import *
