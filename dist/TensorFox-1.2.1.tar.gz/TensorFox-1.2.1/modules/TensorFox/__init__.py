# __init__.py
__version__ = '1.2.1'
def version():
    return (1, 2, 1)

from .TensorFox import *

