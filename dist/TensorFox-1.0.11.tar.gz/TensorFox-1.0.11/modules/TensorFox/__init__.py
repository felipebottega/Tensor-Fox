# __init__.py
__version__ = '1.0.11'
def version():
    return (1, 0, 11)

from .TensorFox import *
