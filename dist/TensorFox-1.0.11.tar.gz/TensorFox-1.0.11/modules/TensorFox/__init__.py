# __init__.py
__version__ = '1.0.12'
def version():
    return (1, 0, 12)

from .TensorFox import *
